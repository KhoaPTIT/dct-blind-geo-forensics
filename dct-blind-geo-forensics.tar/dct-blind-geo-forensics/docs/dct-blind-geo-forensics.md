# dct-blind-geo-forensics

Tac gia: Hoang Anh Khoa  
Ma sinh vien: b22dcat164  
Muc do: Kho  
Chu de: Tan cong hinh hoc vao giau tin anh DCT trong mien tan so.

Lab nay khac lab mau o phan blind challenge: sinh vien khong chi chay cac script tan cong co tham so biet truoc. De lay du checkwork, sinh vien phai tao anh bi tan cong an danh va thuc hien registration/brute-force that de phuc hoi thong diep DCT.

## Muc tieu

1. Nhung thong diep vao anh bang DCT block 8x8 tren cap he so mid-frequency.
2. Do BER khi anh bi translation, crop, rotation, scaling va composite attack.
3. Thuc hien geometric resynchronization de giam BER.
4. Giai blind challenge bang cach quet crop/rotation/translation hypotheses.

Thong diep nhung:

```text
DCT BLIND GEO FORENSIC B22DCAT164
```

## Lenh thuc hanh

Chay tung lenh trong terminal Labtainer:

```bash
python3 generate_cover.py
python3 embed_message.py --alpha 35 --repeat 5
python3 extract_message.py --image stego.png --repeat 5
python3 visualize_dct.py

python3 attack_translation.py --dx 2 --dy 2
python3 attack_translation.py --dx 5 --dy 5
python3 attack_translation.py --dx 10 --dy 10
python3 attack_translation.py --dx 20 --dy 20

python3 attack_crop.py --percent 5
python3 attack_crop.py --percent 10
python3 attack_crop.py --percent 20
python3 attack_crop.py --percent 30

python3 attack_rotation.py --angle 1
python3 attack_rotation.py --angle 3
python3 attack_rotation.py --angle 5
python3 attack_rotation.py --angle 10

python3 attack_scaling.py --scale 90
python3 attack_scaling.py --scale 75
python3 attack_scaling.py --scale 50

python3 attack_composite.py --angle 3 --dx 5 --dy 5 --crop 10
python3 registration_defense.py

python3 challenge_generate.py
python3 recover_challenge.py
python3 summary.py
checkwork
```

## Yeu cau blind challenge

`challenge_generate.py` tao `challenge_blind.png`. Anh nay da bi mot chuoi bien doi hinh hoc ket hop. Direct extraction co BER cao vi block 8x8 bi mat dong bo.

`recover_challenge.py` se thu cac gia thuyet:

- crop percent
- rotation angle
- translation dx,dy

Checkwork chi pass neu `challenge_recovery_report.txt` co marker:

```text
Blind geometric DCT challenge recovered
```

Marker nay chi duoc ghi khi BER tot nhat <= 12% va script da test toi thieu 200 ung vien. Neu muon tang do kho, sinh vien co the mo rong:

```bash
python3 recover_challenge.py --radius 10 --crops 6,8,10,12,14,16 --angles -8,-6,-5,-4,-3,-2,0,2,3,4,5,6,8
```

## Goi y phan tich

So sanh BER giua tung loai attack. Translation nho van co the lam BER tang manh vi extractor doc sai ranh gioi block. Crop va scaling lam noi suy lai toan anh, con rotation tao sai lech khong deu theo vi tri. Defense khong "sua anh" hoan hao, ma tim phep bu lam alignment du tot de cap he so DCT co lai quan he dung.

## Local-first

Lan dau test tren may tao lab:

```bash
cd ~/labtainer/trunk/scripts/labtainer-student
labtainer -r dct-blind-geo-forensics
```

Sau khi rebuild thanh cong moi push image len Docker Hub/GitHub neu can.
