import argparse

from dct_helper import MESSAGE, REPEAT_N, ensure_stego, extract_message, terminal_text, work_path, write_report


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract the hidden message and print BER.")
    parser.add_argument("--image", default="stego.png", help="Image to extract from.")
    parser.add_argument("--repeat", type=int, default=REPEAT_N, help="Repeat count used during embedding.")
    args = parser.parse_args()
    ensure_stego()
    image = work_path(args.image)
    result = extract_message(image, repeat_n=args.repeat)
    ber_percent = result["ber"] * 100.0
    status = "Clean extraction BER = 0.00%" if args.image == "stego.png" and result["ber"] == 0 else f"Extraction BER = {ber_percent:.2f}%"
    write_report(
        work_path("baseline_report.txt"),
        [
            status,
            f"Expected message: {MESSAGE}",
            f"Recovered message: {result['message']}",
            f"REPEAT_N: {result['repeat_n']}",
        ],
    )
    print(f"image={args.image} ber={ber_percent:.2f}%")
    print(f"recovered={terminal_text(result['message'])}")


if __name__ == "__main__":
    main()
