from __future__ import annotations

from geo_attack import crop_resize_image, open_rgb, rotate_image, save_attack, translate_image
from dct_helper import ALPHA, REPEAT_N, embed_message, ensure_cover, extract_message, terminal_text, work_path, write_json, write_report


SECRET_ANGLE = -4
SECRET_DX = 7
SECRET_DY = -6
SECRET_CROP_PERCENT = 12


def main() -> None:
    cover = ensure_cover()
    embed_message(cover, work_path("stego.png"), alpha=ALPHA + 7, repeat_n=REPEAT_N + 2)
    img = open_rgb(work_path("stego.png"))
    attacked = crop_resize_image(img, SECRET_CROP_PERCENT / 100.0)
    attacked = rotate_image(attacked, SECRET_ANGLE)
    attacked = translate_image(attacked, SECRET_DX, SECRET_DY)
    out = work_path("challenge_blind.png")
    save_attack(attacked, out)

    direct = extract_message(out, repeat_n=REPEAT_N + 2)
    write_json(
        work_path("challenge_manifest.json"),
        {
            "image": "challenge_blind.png",
            "repeat_n": REPEAT_N + 2,
            "alpha": ALPHA + 7,
            "direct_ber": direct["ber"],
            "note": "The attack parameters are intentionally not written here. Recover them by search.",
        },
    )
    write_report(
        work_path("challenge_report.txt"),
        [
            "Blind DCT geometric challenge generated",
            "Image: challenge_blind.png",
            f"Direct extraction BER: {direct['ber'] * 100.0:.2f}%",
            f"Direct recovered message: {terminal_text(direct['message'])}",
            "The direct BER should be high. Continue with recover_challenge.py.",
        ],
    )
    print("challenge_blind.png generated")
    print(f"direct_ber={direct['ber'] * 100.0:.2f}% recovered={terminal_text(direct['message'])}")


if __name__ == "__main__":
    main()
