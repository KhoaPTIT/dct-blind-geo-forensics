from pathlib import Path
import runpy


if __name__ == "__main__":
    inner = Path(__file__).resolve().parent / "dct-blind-geo-forensics" / "selftest_local.py"
    runpy.run_path(str(inner), run_name="__main__")
