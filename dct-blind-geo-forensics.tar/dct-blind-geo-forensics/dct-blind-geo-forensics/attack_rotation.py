import argparse

from geo_attack import open_rgb, rotate_image, save_attack
from dct_helper import REPEAT_N, append_metric_row, ensure_stego, extract_message, has_required_rows, terminal_text, work_path, write_report


REQUIRED = {1, 3, 5, 10}


def main() -> None:
    parser = argparse.ArgumentParser(description="Run one rotation attack experiment.")
    parser.add_argument("--angle", type=int, required=True, choices=[1, 3, 5, 10])
    parser.add_argument("--repeat", type=int, default=REPEAT_N)
    args = parser.parse_args()
    stego = ensure_stego()
    img = open_rgb(stego)
    out = work_path(f"attacks/rotation_{args.angle}.png")
    save_attack(rotate_image(img, args.angle), out)
    result = extract_message(out, repeat_n=args.repeat)
    rows = append_metric_row(
        work_path("rotation_metrics.json"),
        ("angle",),
        {"angle": args.angle, "ber": result["ber"], "message": result["message"]},
    )
    complete = has_required_rows(rows, ("angle",), {(x,) for x in REQUIRED})
    lines = ["Rotation Attack BER Analysis" if complete else "Rotation Attack Experiments In Progress"]
    lines.append("Required angle: 1, 3, 5, 10")
    lines.append("angle_degree,BER_percent,recovered_message")
    for row in rows:
        lines.append(f"{row['angle']},{row['ber'] * 100.0:.2f},{row['message']}")
    write_report(work_path("rotation_report.txt"), lines)
    print(f"angle={args.angle} image=attacks/rotation_{args.angle}.png")
    print(f"BER={result['ber'] * 100.0:.2f}% recovered={terminal_text(result['message'])}")
    print("Completed all required rotation levels." if complete else "Run the remaining required rotation levels.")


if __name__ == "__main__":
    main()
