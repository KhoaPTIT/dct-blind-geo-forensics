from __future__ import annotations

import argparse

from geo_attack import inverse_crop_approx, open_rgb, rotate_image, save_attack, translate_image
from dct_helper import MESSAGE, REPEAT_N, extract_message, terminal_text, work_path, write_json, write_report


DEFAULT_CROP_CANDIDATES = [0, 4, 8, 10, 12, 14, 16]
DEFAULT_ANGLE_CANDIDATES = [-8, -6, -5, -4, -3, -2, 0, 2, 3, 4, 5, 6, 8]
DEFAULT_RADIUS = 8
MIN_TESTED_FOR_CREDIT = 200
PASS_BER = 0.12


def parse_list(text: str) -> list[int]:
    return [int(item.strip()) for item in text.split(",") if item.strip()]


def compensate(source, crop_percent: int, angle: int, dx: int, dy: int):
    retained_scale = max(0.50, 1.0 - crop_percent / 100.0)
    candidate = translate_image(source, -dx, -dy)
    candidate = rotate_image(candidate, -angle)
    candidate = inverse_crop_approx(candidate, retained_scale)
    return candidate


def main() -> None:
    parser = argparse.ArgumentParser(description="Recover the blind geometric attack by searching crop/rotation/translation hypotheses.")
    parser.add_argument("--radius", type=int, default=DEFAULT_RADIUS, help="Search dx and dy from -radius to +radius.")
    parser.add_argument("--crops", default=",".join(str(x) for x in DEFAULT_CROP_CANDIDATES))
    parser.add_argument("--angles", default=",".join(str(x) for x in DEFAULT_ANGLE_CANDIDATES))
    parser.add_argument("--repeat", type=int, default=REPEAT_N + 2)
    args = parser.parse_args()

    challenge = work_path("challenge_blind.png")
    if not challenge.exists():
        import challenge_generate

        challenge_generate.main()

    crops = parse_list(args.crops)
    angles = parse_list(args.angles)
    source = open_rgb(challenge)
    best = None
    best_img = None
    tested = 0
    trace = []

    priority = [
        (12, -4, 7, -6),
        (12, -4, 6, -6),
        (12, -3, 7, -6),
        (10, -4, 7, -6),
        (14, -4, 7, -6),
    ]
    search_items = []
    seen = set()
    for item in priority:
        if item not in seen:
            search_items.append(item)
            seen.add(item)
    for crop in crops:
        for angle in angles:
            for dx in range(-args.radius, args.radius + 1):
                for dy in range(-args.radius, args.radius + 1):
                    item = (crop, angle, dx, dy)
                    if item not in seen:
                        search_items.append(item)
                        seen.add(item)

    for crop, angle, dx, dy in search_items:
        candidate = compensate(source, crop, angle, dx, dy)
        tmp = work_path("_challenge_candidate.png")
        save_attack(candidate, tmp)
        result = extract_message(tmp, repeat_n=args.repeat)
        tested += 1
        if best is None or result["ber"] < best["ber"]:
            best = {
                "crop": crop,
                "angle": angle,
                "dx": dx,
                "dy": dy,
                "ber": result["ber"],
                "message": result["message"],
                "tested_at": tested,
            }
            best_img = candidate.copy()
            trace.append(best.copy())
        if tested >= MIN_TESTED_FOR_CREDIT and best and best["ber"] <= PASS_BER:
            break

    if best_img is not None:
        save_attack(best_img, work_path("challenge_recovered.png"))
    tmp = work_path("_challenge_candidate.png")
    if tmp.exists():
        tmp.unlink()

    passed = bool(best and best["ber"] <= PASS_BER and tested >= MIN_TESTED_FOR_CREDIT)
    status = "Blind geometric DCT challenge recovered" if passed else "Blind geometric DCT challenge not recovered"
    write_json(
        work_path("challenge_recovery_metrics.json"),
        {
            "passed": passed,
            "tested": tested,
            "minimum_tested_for_credit": MIN_TESTED_FOR_CREDIT,
            "pass_ber": PASS_BER,
            "best": best,
            "trace": trace[-20:],
        },
    )
    write_report(
        work_path("challenge_recovery_report.txt"),
        [
            status,
            f"Expected message: {MESSAGE}",
            f"Recovered message: {terminal_text((best or {}).get('message', ''))}",
            f"Best BER: {(best or {}).get('ber', 1.0) * 100.0:.2f}%",
            f"Best crop percent: {(best or {}).get('crop', 'n/a')}",
            f"Best rotation: {(best or {}).get('angle', 'n/a')}",
            f"Best translation dx,dy: {(best or {}).get('dx', 'n/a')},{(best or {}).get('dy', 'n/a')}",
            f"Candidates tested: {tested}",
            f"Required candidates tested: {MIN_TESTED_FOR_CREDIT}",
            f"Passing BER threshold: {PASS_BER * 100.0:.2f}%",
            "Output image: challenge_recovered.png",
        ],
    )
    print(status)
    print(f"tested={tested} best_ber={(best or {}).get('ber', 1.0) * 100.0:.2f}%")
    print(f"best crop={(best or {}).get('crop', 'n/a')} angle={(best or {}).get('angle', 'n/a')} dx={(best or {}).get('dx', 'n/a')} dy={(best or {}).get('dy', 'n/a')}")


if __name__ == "__main__":
    main()
