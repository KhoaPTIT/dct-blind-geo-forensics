import argparse

from geo_attack import composite_attack, open_rgb, save_attack
from dct_helper import REPEAT_N, ensure_stego, extract_message, terminal_text, work_path, write_json, write_report


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a composite geometric attack.")
    parser.add_argument("--angle", type=float, default=3.0)
    parser.add_argument("--dx", type=int, default=5)
    parser.add_argument("--dy", type=int, default=5)
    parser.add_argument("--crop", type=int, default=10, help="Crop percentage.")
    parser.add_argument("--repeat", type=int, default=REPEAT_N)
    args = parser.parse_args()
    stego = ensure_stego()
    img = open_rgb(stego)
    out = work_path("attacks/composite_attacked.png")
    save_attack(composite_attack(img, angle=args.angle, dx=args.dx, dy=args.dy, crop_percent=args.crop / 100.0), out)
    save_attack(open_rgb(out), work_path("composite_attacked.png"))
    result = extract_message(out, repeat_n=args.repeat)
    write_json(work_path("composite_metrics.json"), {"ber": result["ber"], "angle": args.angle, "dx": args.dx, "dy": args.dy, "crop": args.crop})
    write_report(
        work_path("composite_report.txt"),
        [
            "Composite Geometric Attack BER Analysis",
            f"attack=rotate {args.angle:g} degree, translate {args.dx},{args.dy} px, crop {args.crop} percent",
            f"BER: {result['ber'] * 100.0:.2f}%",
            f"Recovered message: {result['message']}",
        ],
    )
    print(f"angle={args.angle:g} dx={args.dx} dy={args.dy} crop={args.crop}%")
    print(f"BER={result['ber'] * 100.0:.2f}% recovered={terminal_text(result['message'])}")
    print("Images: attacks/composite_attacked.png and composite_attacked.png")


if __name__ == "__main__":
    main()
