# LOCAL_TEST_COMMANDS

Quy trinh local-first cho nguoi tao lab. Khong push GitHub hoac DockerHub trong buoc nay.

## Buoc 1: Kiem tra source lab

```bash
cd ~/labtainer/trunk/labs/dct-blind-geo-forensics
```

## Buoc 2: Kiem tra syntax Python

```bash
python3 -m py_compile *.py
```

## Buoc 3: Chay selftest logic Python

```bash
python3 selftest_local.py
```

## Buoc 4: Rebuild va chay lab local

```bash
cd ~/labtainer/trunk/scripts/labtainer-student
labtainer -r dct-blind-geo-forensics
```

## Buoc 5: Trong terminal container, chay lan luot

```bash
python3 generate_cover.py
python3 embed_message.py --alpha 25 --repeat 3
python3 extract_message.py --image stego.png --repeat 3
python3 embed_message.py --alpha 35 --repeat 5
python3 extract_message.py --image stego.png --repeat 5
python3 visualize_dct.py
python3 attack_translation.py --dx 2 --dy 2
python3 attack_translation.py --dx 5 --dy 5
python3 attack_translation.py --dx 10 --dy 10
python3 attack_translation.py --dx 20 --dy 20
python3 attack_crop.py --percent 5
python3 attack_crop.py --percent 10
python3 attack_crop.py --percent 20
python3 attack_crop.py --percent 30
python3 attack_rotation.py --angle 1
python3 attack_rotation.py --angle 3
python3 attack_rotation.py --angle 5
python3 attack_rotation.py --angle 10
python3 attack_scaling.py --scale 90
python3 attack_scaling.py --scale 75
python3 attack_scaling.py --scale 50
python3 attack_composite.py --angle 3 --dx 5 --dy 5 --crop 10
python3 registration_defense.py
python3 challenge_generate.py
python3 recover_challenge.py
python3 summary.py
```

## Buoc 6: Checkwork

```bash
checkwork
```

## Buoc 7: Dung lab

```bash
stoplab dct-blind-geo-forensics
```
