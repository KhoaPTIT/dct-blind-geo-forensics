# STUDENT_GUIDE - dct-blind-geo-forensics

Lab nay ve tan cong hinh hoc vao giau tin anh DCT. Phan kho la blind challenge: phai thuc su quet tham so bu hinh hoc de phuc hoi thong diep, khong chi chay mot attack co tham so biet truoc.

Thong diep can phuc hoi:

```text
DCT BLIND GEO FORENSIC B22DCAT164
```

## Chay cac task

```bash
python3 generate_cover.py
python3 embed_message.py --alpha 35 --repeat 5
python3 extract_message.py --image stego.png --repeat 5
python3 visualize_dct.py
python3 attack_translation.py --dx 2 --dy 2
python3 attack_translation.py --dx 5 --dy 5
python3 attack_translation.py --dx 10 --dy 10
python3 attack_translation.py --dx 20 --dy 20
python3 attack_crop.py --percent 5
python3 attack_crop.py --percent 10
python3 attack_crop.py --percent 20
python3 attack_crop.py --percent 30
python3 attack_rotation.py --angle 1
python3 attack_rotation.py --angle 3
python3 attack_rotation.py --angle 5
python3 attack_rotation.py --angle 10
python3 attack_scaling.py --scale 90
python3 attack_scaling.py --scale 75
python3 attack_scaling.py --scale 50
python3 attack_composite.py --angle 3 --dx 5 --dy 5 --crop 10
python3 registration_defense.py
python3 challenge_generate.py
python3 recover_challenge.py
python3 summary.py
checkwork
```

## Blind challenge

`challenge_generate.py` tao `challenge_blind.png`. Direct extraction se co BER cao.

`recover_challenge.py` thu nhieu gia thuyet crop/rotation/translation, tao `challenge_recovered.png` va report BER tot nhat. Checkwork chi dat khi:

- BER tot nhat <= 12%.
- Da thu toi thieu 200 ung vien.
- `challenge_recovery_report.txt` co dong `Blind geometric DCT challenge recovered`.

Co the mo rong khong gian tim kiem:

```bash
python3 recover_challenge.py --radius 10 --crops 6,8,10,12,14,16 --angles -8,-6,-5,-4,-3,-2,0,2,3,4,5,6,8
```

## Can nam

DCT block 8x8 nhung bit vao cap he so mid-frequency. Khi anh bi dich, crop, xoay hoac scale, extractor khong doc dung block da nhung nua, nen BER tang. Registration defense la tim phep bien doi nguoc du tot de dong bo lai block.
