import argparse

from geo_attack import open_rgb, save_attack, translate_image
from dct_helper import REPEAT_N, append_metric_row, ensure_stego, extract_message, has_required_rows, terminal_text, work_path, write_report


REQUIRED = {(2, 2), (5, 5), (10, 10), (20, 20)}


def main() -> None:
    parser = argparse.ArgumentParser(description="Run one translation attack experiment.")
    parser.add_argument("--dx", type=int, required=True, help="Horizontal shift in pixels.")
    parser.add_argument("--dy", type=int, required=True, help="Vertical shift in pixels.")
    parser.add_argument("--repeat", type=int, default=REPEAT_N)
    args = parser.parse_args()
    stego = ensure_stego()
    img = open_rgb(stego)
    out = work_path(f"attacks/translation_{args.dx}_{args.dy}.png")
    save_attack(translate_image(img, args.dx, args.dy), out)
    result = extract_message(out, repeat_n=args.repeat)
    rows = append_metric_row(
        work_path("translation_metrics.json"),
        ("dx", "dy"),
        {"dx": args.dx, "dy": args.dy, "ber": result["ber"], "message": result["message"]},
    )
    complete = has_required_rows(rows, ("dx", "dy"), REQUIRED)
    lines = ["Translation Attack BER Analysis" if complete else "Translation Attack Experiments In Progress"]
    lines.append("Required dx,dy: (2,2), (5,5), (10,10), (20,20)")
    lines.append("dx,dy,BER_percent,recovered_message")
    for row in rows:
        lines.append(f"{row['dx']},{row['dy']},{row['ber'] * 100.0:.2f},{row['message']}")
    write_report(work_path("translation_report.txt"), lines)
    print(f"dx={args.dx} dy={args.dy} image=attacks/translation_{args.dx}_{args.dy}.png")
    print(f"BER={result['ber'] * 100.0:.2f}% recovered={terminal_text(result['message'])}")
    print("Completed all required translation levels." if complete else "Run the remaining required dx,dy levels.")


if __name__ == "__main__":
    main()
