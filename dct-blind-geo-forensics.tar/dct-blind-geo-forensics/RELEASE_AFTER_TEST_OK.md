# RELEASE_AFTER_TEST_OK

Chi lam cac buoc nay sau khi da test local OK. Khong push tu dong.

1. Kiem tra image local:

```bash
docker images | grep dct-blind-geo-forensics
```

2. Tag image sang DockerHub registry `hackato`:

```bash
docker tag dct-blind-geo-forensics.dct-blind-geo-forensics.student:latest hackato/dct-blind-geo-forensics.dct-blind-geo-forensics.student:latest
```

Neu ten image local khac, dung IMAGE ID:

```bash
docker tag <IMAGE_ID> hackato/dct-blind-geo-forensics.dct-blind-geo-forensics.student:latest
```

3. Push DockerHub:

```bash
docker login
docker push hackato/dct-blind-geo-forensics.dct-blind-geo-forensics.student:latest
```

4. Sau khi DockerHub co image, moi push file `dct-blind-geo-forensics.tar` len GitHub.

5. Khi do nguoi khac moi chay:

```bash
imodule https://github.com/<repo>/raw/main/dct-blind-geo-forensics.tar
labtainer dct-blind-geo-forensics
```

Luu y: nguoi tao lab test lan dau bang `labtainer -r dct-blind-geo-forensics`. Nguoi dung cuoi chi chay `labtainer dct-blind-geo-forensics` sau khi image da duoc push len DockerHub `hackato`.
