from __future__ import annotations

from pathlib import Path

from PIL import Image

from dct_helper import IMAGE_SIZE


FILL = (128, 128, 128)
AFFINE = getattr(getattr(Image, "Transform", Image), "AFFINE", Image.AFFINE)
BICUBIC = getattr(getattr(Image, "Resampling", Image), "BICUBIC", Image.BICUBIC)


def open_rgb(path: str | Path) -> Image.Image:
    return Image.open(path).convert("RGB").resize((IMAGE_SIZE, IMAGE_SIZE))


def translate_image(img: Image.Image, dx: int, dy: int) -> Image.Image:
    return img.transform(
        img.size,
        AFFINE,
        (1, 0, -dx, 0, 1, -dy),
        resample=BICUBIC,
        fillcolor=FILL,
    )


def crop_resize_image(img: Image.Image, percent: float) -> Image.Image:
    margin = int(round((percent / 2.0) * IMAGE_SIZE))
    box = (margin, margin, IMAGE_SIZE - margin, IMAGE_SIZE - margin)
    return img.crop(box).resize((IMAGE_SIZE, IMAGE_SIZE), BICUBIC)


def rotate_image(img: Image.Image, angle: float) -> Image.Image:
    return img.rotate(angle, resample=BICUBIC, expand=False, fillcolor=FILL)


def scale_down_up_image(img: Image.Image, scale: float) -> Image.Image:
    small_size = max(8, int(round(IMAGE_SIZE * scale)))
    return img.resize((small_size, small_size), BICUBIC).resize(
        (IMAGE_SIZE, IMAGE_SIZE), BICUBIC
    )


def composite_attack(img: Image.Image, angle: float = 3.0, dx: int = 5, dy: int = 5, crop_percent: float = 0.10) -> Image.Image:
    attacked = rotate_image(img, angle)
    attacked = translate_image(attacked, dx, dy)
    attacked = crop_resize_image(attacked, crop_percent)
    return attacked


def inverse_crop_approx(img: Image.Image, retained_scale: float) -> Image.Image:
    retained_size = max(8, int(round(IMAGE_SIZE * retained_scale)))
    canvas = Image.new("RGB", (IMAGE_SIZE, IMAGE_SIZE), FILL)
    resized = img.resize((retained_size, retained_size), BICUBIC)
    offset = ((IMAGE_SIZE - retained_size) // 2, (IMAGE_SIZE - retained_size) // 2)
    canvas.paste(resized, offset)
    return canvas


def save_attack(img: Image.Image, path: str | Path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    img.save(path)
